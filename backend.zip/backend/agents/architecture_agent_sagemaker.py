"""Strands Agent for Cloud Architecture - SageMaker/NVIDIA NIM Version

This version uses:
- Llama 3.1 Nemotron Nano 8B (NVIDIA NIM on SageMaker)
- Retrieval Embedding NIM for RAG
- Custom cloud architecture tools

Required for NVIDIA-AWS Hackathon.
"""

import os
from typing import Optional
from strands import Agent
from backend.models.sagemaker_model import SageMakerNIMModel
from backend.tools.cloud_tools import (
    get_aws_service_info,
    calculate_architecture_cost,
    suggest_cost_optimization,
    get_service_alternatives,
    validate_architecture
)
from backend.utils.embedding_nim import get_embedding_nim


class ArchitectureAgentSageMaker:
    """
    AI Agent for cloud architecture design using NVIDIA NIMs on SageMaker

    Features:
    - Llama 3.1 Nemotron Nano 8B for architecture generation
    - Retrieval Embedding NIM for RAG-enhanced recommendations
    - Custom tools for cloud service information and cost calculation
    """

    def __init__(
        self,
        llm_endpoint: Optional[str] = None,
        embedding_endpoint: Optional[str] = None,
        region: Optional[str] = None
    ):
        """
        Initialize with SageMaker endpoints

        Args:
            llm_endpoint: SageMaker endpoint for Llama 3.1 Nemotron
            embedding_endpoint: SageMaker endpoint for Embedding NIM
            region: AWS region
        """
        self.region = region or os.getenv("AWS_DEFAULT_REGION", "us-west-2")

        print(f"\n{'='*80}")
        print(f"🚀 Initializing Architecture Agent (NVIDIA-AWS Hackathon Version)")
        print(f"{'='*80}")

        # Initialize NVIDIA Llama 3.1 Nemotron NIM on SageMaker
        self.model = SageMakerNIMModel(
            endpoint_name=llm_endpoint or os.getenv("SAGEMAKER_ENDPOINT_NAME"),
            region_name=self.region,
            temperature=0.7,
            streaming=False
        )

        # Initialize Retrieval Embedding NIM
        self.embedding_nim = get_embedding_nim()

        # System prompt for architecture agent
        system_prompt = """You are an expert cloud architecture AI agent specialized in AWS, Azure, and Google Cloud Platform.

Your role is to help users design optimal, secure, and cost-effective cloud architectures.

Key Responsibilities:
1. Analyze user requirements and recommend appropriate cloud services
2. Design complete architectures with proper service connections
3. Estimate costs accurately using your tools
4. Suggest cost optimizations and alternatives
5. Validate architectures for best practices and security
6. Provide clear reasoning for your recommendations

Available Tools:
- get_aws_service_info: Get details about AWS services
- calculate_architecture_cost: Calculate total architecture cost
- suggest_cost_optimization: Find cost-saving alternatives
- get_service_alternatives: Get equivalent services across cloud providers
- validate_architecture: Check architecture for best practices

Guidelines:
- Always use tools to get accurate service information and costs
- Provide specific, actionable recommendations
- Consider security, scalability, and cost in all designs
- Explain trade-offs between different approaches
- Follow cloud best practices (high availability, disaster recovery, monitoring)

CRITICAL OUTPUT FORMAT:
You MUST return your response in this EXACT JSON structure, followed by detailed markdown reasoning:

```json
{
  "architecture": {
    "title": "Project Title",
    "description": "Brief project description",
    "provider": "aws|azure|gcp",
    "total_cost": 229.00,
    "services": [
      {
        "id": "service-1",
        "name": "EC2 Instance",
        "type": "compute",
        "cost": 29.20,
        "description": "Primary application server",
        "icon": "server",
        "position": {"x": 300, "y": 200}
      }
    ],
    "connections": [
      {"from": "service-1", "to": "service-2", "type": "HTTP/HTTPS"}
    ],
    "alternatives": [
      {
        "service_id": "service-1",
        "alternative_name": "EC2 t3.small",
        "cost": 14.60,
        "savings": 14.60,
        "performance": 70,
        "description": "Smaller instance size"
      }
    ]
  }
}
```

IMPORTANT NODE POSITIONING RULES:
- Space nodes FAR APART to prevent visual clutter
- Minimum horizontal spacing: 400 pixels
- Minimum vertical spacing: 300 pixels
- Arrange in logical layers (frontend, backend, data)

Then provide detailed markdown explanation with:
- Architecture overview
- Security best practices
- Cost breakdown
- Optimization recommendations
- Implementation steps"""

        # Create agent with SageMaker model and tools
        self.agent = Agent(
            model=self.model,
            system_prompt=system_prompt,
            tools=[
                get_aws_service_info,
                calculate_architecture_cost,
                suggest_cost_optimization,
                get_service_alternatives,
                validate_architecture
            ]
        )

        print(f"✅ Agent initialized with NVIDIA NIMs")
        print(f"   - LLM: Llama 3.1 Nemotron Nano 8B")
        print(f"   - Embedding: NVIDIA Retrieval NIM")
        print(f"   - Tools: 5 cloud architecture tools")
        print(f"{'='*80}\n")

    def generate_architecture(self, requirements: str) -> str:
        """
        Generate architecture with RAG using Embedding NIM

        This demonstrates the NVIDIA-AWS Hackathon requirement for using Retrieval Embedding NIM.

        Args:
            requirements: User's architecture requirements

        Returns:
            Agent's architecture recommendation with JSON and reasoning
        """
        print(f"\n{'='*60}")
        print(f"🏗️ ARCHITECTURE GENERATION (with RAG)")
        print(f"{'='*60}")
        print(f"Requirements: {requirements[:100]}...")

        # Cloud architecture knowledge base for RAG
        knowledge_base = [
            "High availability requires multi-AZ deployment with load balancers and auto-scaling groups",
            "Microservices benefit from container orchestration like ECS or EKS with service mesh",
            "Serverless architectures use Lambda for compute, API Gateway for APIs, and DynamoDB for data",
            "E-commerce needs CDN (CloudFront), auto-scaling web/app tiers, managed databases (RDS), and caching (ElastiCache)",
            "Cost optimization: use spot instances for batch jobs, reserved capacity for steady workloads, S3 lifecycle policies",
            "Security best practices: VPC with private subnets, security groups, NACLs, encryption at rest and in transit, IAM least privilege",
            "Media processing: use S3 for storage, Lambda for triggers, MediaConvert for transcoding, CloudFront for delivery",
            "Machine learning: SageMaker for training and inference, S3 for data lake, Glue for ETL",
            "Real-time analytics: Kinesis for streaming, Lambda for processing, OpenSearch for analysis, QuickSight for dashboards",
            "Gaming backend: GameLift for hosting, DynamoDB for player data, ElastiCache for leaderboards, CloudFront for CDN"
        ]

        # Use Retrieval Embedding NIM for semantic search (HACKATHON REQUIREMENT!)
        print(f"\n🔍 Using Retrieval Embedding NIM for RAG...")
        relevant_context = self.embedding_nim.similarity_search(
            query=requirements,
            documents=knowledge_base,
            top_k=3
        )

        # Build enhanced prompt with retrieval context
        context_text = "\n".join([
            f"- {item['document']} (relevance: {item['score']:.2f})"
            for item in relevant_context
        ])

        print(f"\n📚 Retrieved Context (Top 3):")
        for item in relevant_context:
            print(f"   [{item['score']:.3f}] {item['document'][:80]}...")

        # Build final prompt with RAG context
        prompt = f"""Design a cloud architecture based on these requirements:

{requirements}

Relevant Cloud Architecture Patterns (Retrieved via NVIDIA Embedding NIM):
{context_text}

Please:
1. Recommend specific AWS services (use get_aws_service_info for details)
2. Calculate the total cost (use calculate_architecture_cost)
3. Suggest how services should connect
4. Validate the architecture (use validate_architecture)
5. Provide security best practices
6. Suggest cost optimizations if possible

Be specific and provide a complete, production-ready architecture."""

        print(f"\n🤖 Calling Llama 3.1 Nemotron on SageMaker...")

        # Call agent with RAG-enhanced prompt
        response = self.agent(prompt)

        print(f"✅ Architecture generated successfully")
        print(f"{'='*60}\n")

        return response

    def optimize_architecture(self, current_architecture: str, optimization_goal: str) -> str:
        """
        Optimize architecture with embedding-based recommendations

        Args:
            current_architecture: Description of current architecture
            optimization_goal: 'cost', 'performance', or 'balanced'

        Returns:
            Optimization recommendations
        """
        print(f"\n{'='*60}")
        print(f"⚡ ARCHITECTURE OPTIMIZATION (with RAG)")
        print(f"{'='*60}")
        print(f"Goal: {optimization_goal}")

        # Optimization patterns knowledge base
        optimization_patterns = [
            "Replace on-demand EC2 instances with reserved or spot instances for 50-70% cost savings",
            "Use Aurora Serverless instead of RDS for variable workloads to scale to zero during idle",
            "Implement CloudFront CDN for static content delivery to reduce origin load and improve performance",
            "Use Lambda instead of EC2 for sporadic or event-driven workloads to pay only for execution time",
            "Enable S3 Intelligent-Tiering for automatic cost optimization based on access patterns",
            "Use Application Load Balancer with path-based routing instead of multiple Classic Load Balancers",
            "Implement ElastiCache for frequently accessed data to reduce database load",
            "Use AWS Fargate instead of EC2 for containers to eliminate server management overhead",
            "Enable RDS read replicas for read-heavy workloads to improve performance",
            "Use Amazon EBS gp3 volumes instead of gp2 for 20% cost savings with same performance"
        ]

        # Use Embedding NIM to find relevant optimization patterns
        print(f"\n🔍 Using Retrieval Embedding NIM for optimization patterns...")
        relevant_optimizations = self.embedding_nim.similarity_search(
            query=f"{optimization_goal} optimization for {current_architecture}",
            documents=optimization_patterns,
            top_k=3
        )

        context_text = "\n".join([
            f"- {opt['document']}"
            for opt in relevant_optimizations
        ])

        print(f"\n📚 Retrieved Optimization Patterns:")
        for opt in relevant_optimizations:
            print(f"   [{opt['score']:.3f}] {opt['document'][:80]}...")

        prompt = f"""Analyze and optimize this architecture with goal: {optimization_goal}

Current Architecture:
{current_architecture}

Recommended Optimization Patterns (Retrieved via NVIDIA Embedding NIM):
{context_text}

Please:
1. Identify optimization opportunities using suggest_cost_optimization
2. Calculate potential savings
3. Suggest alternative services where beneficial
4. Maintain or improve performance
5. Ensure security is not compromised
6. Provide implementation steps

Focus on practical, high-impact optimizations."""

        print(f"\n🤖 Calling Llama 3.1 Nemotron on SageMaker...")
        response = self.agent(prompt)

        print(f"✅ Optimization completed")
        print(f"{'='*60}\n")

        return response

    def validate_design(self, architecture_description: str) -> str:
        """
        Validate architecture design

        Args:
            architecture_description: Architecture to validate

        Returns:
            Validation results with recommendations
        """
        prompt = f"""Validate this cloud architecture design:

{architecture_description}

Use the validate_architecture tool and provide:
1. Validation results
2. Security concerns
3. Scalability issues
4. Best practice violations
5. Recommended improvements
6. Priority of each issue"""

        return self.agent(prompt)

    def compare_providers(self, service_name: str) -> str:
        """
        Compare a service across cloud providers

        Args:
            service_name: Service to compare

        Returns:
            Comparison across AWS, Azure, GCP
        """
        prompt = f"""Compare the service "{service_name}" across AWS, Azure, and Google Cloud.

Use get_service_alternatives tool and provide:
1. Equivalent services in each cloud
2. Key feature differences
3. Cost comparison (if available)
4. When to choose each provider
5. Migration considerations"""

        return self.agent(prompt)

    def answer_question(self, question: str, context: Optional[str] = None) -> str:
        """
        Answer general architecture questions

        Args:
            question: User's question
            context: Optional context about their architecture

        Returns:
            Agent's answer
        """
        if context:
            prompt = f"""Context: {context}

Question: {question}

Provide a clear, practical answer using tools if needed."""
        else:
            prompt = question

        return self.agent(prompt)


# Singleton instance
_agent_instance_sagemaker: Optional[ArchitectureAgentSageMaker] = None


def get_architecture_agent_sagemaker() -> ArchitectureAgentSageMaker:
    """Get or create the SageMaker architecture agent singleton"""
    global _agent_instance_sagemaker

    if _agent_instance_sagemaker is None:
        _agent_instance_sagemaker = ArchitectureAgentSageMaker()

    return _agent_instance_sagemaker
