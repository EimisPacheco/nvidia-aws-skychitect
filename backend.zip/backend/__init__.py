"""Skyrchitect AI Backend - AWS Agent Hackathon 2025"""
__version__ = "1.0.0"
