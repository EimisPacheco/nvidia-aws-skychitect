"""Retrieval Embedding NIM Client for SageMaker - NVIDIA-AWS Hackathon"""

import boto3
import json
import os
from typing import List, Dict, Any, Optional


class RetrievalEmbeddingNIM:
    """
    Client for NVIDIA Retrieval Embedding NIM deployed on SageMaker

    This provides enterprise-grade embedding and retrieval capabilities for RAG applications.
    Required for NVIDIA-AWS Hackathon.
    """

    def __init__(
        self,
        endpoint_name: str = None,
        region_name: str = None
    ):
        """
        Initialize Retrieval Embedding NIM client

        Args:
            endpoint_name: SageMaker endpoint name for embedding NIM
            region_name: AWS region
        """
        self.endpoint_name = endpoint_name or os.getenv(
            "EMBEDDING_ENDPOINT_NAME",
            "embedding-nim-endpoint"
        )
        self.region_name = region_name or os.getenv("AWS_DEFAULT_REGION", "us-west-2")

        self.runtime = boto3.client(
            'sagemaker-runtime',
            region_name=self.region_name
        )

        # Flag to track if endpoint exists
        self.endpoint_available = False
        self._check_endpoint()

        print(f"✅ Retrieval Embedding NIM initialized: {self.endpoint_name}")

    def _check_endpoint(self):
        """Check if SageMaker endpoint exists"""
        try:
            sagemaker = boto3.client('sagemaker', region_name=self.region_name)
            response = sagemaker.describe_endpoint(EndpointName=self.endpoint_name)
            status = response['EndpointStatus']

            if status == 'InService':
                self.endpoint_available = True
                print(f"✅ Embedding endpoint is InService")
            else:
                print(f"⚠️ Embedding endpoint status: {status}")

        except Exception as e:
            print(f"⚠️ Embedding endpoint not yet deployed: {e}")
            print(f"   Using fallback embeddings for now")

    def embed_query(self, text: str) -> List[float]:
        """
        Generate embedding for a search query

        Args:
            text: Query text to embed

        Returns:
            Embedding vector (list of floats)
        """
        if not self.endpoint_available:
            # Fallback: return dummy embedding for development
            print(f"⚠️ Using fallback embedding (endpoint not available)")
            return self._fallback_embedding(text)

        try:
            payload = {
                "input": text,
                "input_type": "query",
                "encoding_format": "float",
                "truncate": "END"
            }

            response = self.runtime.invoke_endpoint(
                EndpointName=self.endpoint_name,
                ContentType='application/json',
                Body=json.dumps(payload)
            )

            result = json.loads(response['Body'].read().decode())

            # NVIDIA NIM embedding format
            if 'data' in result and len(result['data']) > 0:
                return result['data'][0]['embedding']

            # Fallback
            return self._fallback_embedding(text)

        except Exception as e:
            print(f"⚠️ Embedding error: {e}, using fallback")
            return self._fallback_embedding(text)

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        """
        Generate embeddings for multiple documents

        Args:
            texts: List of document texts

        Returns:
            List of embedding vectors
        """
        if not self.endpoint_available:
            return [self._fallback_embedding(text) for text in texts]

        try:
            payload = {
                "input": texts,
                "input_type": "passage",
                "encoding_format": "float",
                "truncate": "END"
            }

            response = self.runtime.invoke_endpoint(
                EndpointName=self.endpoint_name,
                ContentType='application/json',
                Body=json.dumps(payload)
            )

            result = json.loads(response['Body'].read().decode())

            if 'data' in result:
                return [item['embedding'] for item in result['data']]

            return [self._fallback_embedding(text) for text in texts]

        except Exception as e:
            print(f"⚠️ Batch embedding error: {e}, using fallback")
            return [self._fallback_embedding(text) for text in texts]

    def similarity_search(
        self,
        query: str,
        documents: List[str],
        top_k: int = 5
    ) -> List[Dict[str, Any]]:
        """
        Perform similarity search using embeddings

        This is the RAG component required for NVIDIA-AWS Hackathon.

        Args:
            query: Search query
            documents: List of documents to search
            top_k: Number of top results to return

        Returns:
            List of dicts with 'index', 'document', and 'score'
        """
        print(f"🔍 Similarity search: query='{query[:50]}...', {len(documents)} docs")

        # Get embeddings
        query_embedding = self.embed_query(query)
        doc_embeddings = self.embed_documents(documents)

        # Calculate cosine similarities
        similarities = []
        for idx, doc_emb in enumerate(doc_embeddings):
            similarity = self._cosine_similarity(query_embedding, doc_emb)
            similarities.append({
                'index': idx,
                'document': documents[idx],
                'score': float(similarity)
            })

        # Sort by similarity score (highest first)
        similarities.sort(key=lambda x: x['score'], reverse=True)

        results = similarities[:top_k]
        print(f"✅ Found {len(results)} relevant documents")
        for r in results[:3]:
            print(f"   - Score {r['score']:.3f}: {r['document'][:60]}...")

        return results

    def _cosine_similarity(self, vec1: List[float], vec2: List[float]) -> float:
        """Calculate cosine similarity between two vectors"""
        import math

        dot_product = sum(a * b for a, b in zip(vec1, vec2))
        norm1 = math.sqrt(sum(a * a for a in vec1))
        norm2 = math.sqrt(sum(b * b for b in vec2))

        if norm1 == 0 or norm2 == 0:
            return 0.0

        return dot_product / (norm1 * norm2)

    def _fallback_embedding(self, text: str) -> List[float]:
        """
        Generate a simple hash-based embedding for fallback

        This is used when the SageMaker endpoint is not available yet.
        In production, the real NVIDIA Embedding NIM would be used.
        """
        # Simple deterministic embedding based on text content
        # In reality, this would use the NVIDIA NIM
        hash_val = hash(text)
        embedding_dim = 384  # Common embedding dimension

        # Create pseudo-random but deterministic embedding
        embedding = []
        for i in range(embedding_dim):
            # Use text content and position to generate values
            seed = hash_val + i
            value = (seed % 1000) / 1000.0 - 0.5  # Range: -0.5 to 0.5
            embedding.append(value)

        return embedding


# Singleton instance
_embedding_nim_instance: Optional[RetrievalEmbeddingNIM] = None


def get_embedding_nim() -> RetrievalEmbeddingNIM:
    """
    Get or create Retrieval Embedding NIM singleton

    Returns:
        RetrievalEmbeddingNIM instance
    """
    global _embedding_nim_instance

    if _embedding_nim_instance is None:
        _embedding_nim_instance = RetrievalEmbeddingNIM()

    return _embedding_nim_instance
