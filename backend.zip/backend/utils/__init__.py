"""Utility modules for backend"""
